#!/usr/bin/env python3
import os, sys

if __name__ == '__main__':
    os.system("python webapp/manage.py runserver")